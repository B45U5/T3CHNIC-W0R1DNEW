package pl.B4GU5.TW.Controllers;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.management.ManagementFactory;
import java.lang.management.OperatingSystemMXBean;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.swing.event.HyperlinkEvent;

import org.apache.commons.codec.binary.Hex;
import org.codefx.libfx.control.webview.WebViewHyperlinkListener;
import org.codefx.libfx.control.webview.WebViews;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXCheckBox;
import com.jfoenix.controls.JFXDialog;
import com.jfoenix.controls.JFXDialogLayout;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXProgressBar;
import com.jfoenix.controls.JFXSlider;
import com.jfoenix.controls.JFXTextArea;
import com.jfoenix.controls.JFXTextField;

import de.jensd.fx.glyphs.materialdesignicons.MaterialDesignIconView;
import de.schlegel11.jfxanimation.JFXAnimationTemplates;
import javafx.animation.Timeline;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.concurrent.Worker;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.effect.BoxBlur;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import pl.B4GU5.TW.Main;
import pl.B4GU5.TW.Animations.animations;
import pl.B4GU5.Utils.Browser;
import pl.B4GU5.Utils.LogType;
import pl.B4GU5.Utils.Logger;
import pl.B4GU5.Utils.jsonReader;
import pl.B4GU5.Utils.modsListClass;
import pl.B4GU5.Utils.settings;
import uk.co.rx14.jmclaunchlib.LaunchSpec;
import uk.co.rx14.jmclaunchlib.LaunchTask;
import uk.co.rx14.jmclaunchlib.LaunchTaskBuilder;
import uk.co.rx14.jmclaunchlib.util.OS;

public class MainController {
	
	private Boolean isPlayable = false;
	private ArrayList<modsListClass> modsList = new ArrayList<modsListClass>();
	private ArrayList<modsListClass> modsListInDir = new ArrayList<modsListClass>();
	private ArrayList<String> addonsList = new ArrayList<String>();
    public String slash = File.separator;
    private int mods = 0;
    private String modsPath = settings.getWorkingDir() + slash + settings.getPack() + slash + "Minecraft" + slash + "mods";
    private String minecraftPath = settings.getWorkingDir() + slash + settings.getPack() + slash + "Minecraft";
    private String urlModsPath = "https://api.technicworld.pl/api/modpack-" + settings.getPack();
    private String urlAddonsList = "https://api.technicworld.pl/api/addons_" + settings.getPack() + ".json";
    private String urlModsList = "https://api.technicworld.pl/api/mods-" + settings.getPack() + ".json";
    private String packVersion = "0.0.0";
    private static Double rame = (double) 3;
    private static Double rammc;
    
    @FXML
    private AnchorPane consolePane;
	@FXML
	private Label playText;
	@FXML
	private MaterialDesignIconView settingsICON;
	@FXML
	private MaterialDesignIconView downloadIcon;
	@FXML
	private Label loginButtonText;
	@FXML
	private WebView webBrowser;
	@FXML
	private JFXProgressBar browserProgress;
	@FXML
	private AnchorPane loginPane;
	@FXML
	private AnchorPane mainPane;
	@FXML
	private VBox loginFormPane;
	@FXML
	private VBox loadingText;
	@FXML
	private AnchorPane menuLeftPane;
	@FXML
	private AnchorPane menuPackLeftPane;
	@FXML
	private AnchorPane modpackPane;
	@FXML
	private JFXTextField loginField;
	@FXML
	private JFXPasswordField passwordField;
	@FXML
	private Text loginText;
	@FXML
	private JFXProgressBar loginLoading;
	@FXML
	private Text nick;
	@FXML
	private Text rankTxt;
	@FXML
	private Button skyblockButton;
	@FXML
	private Button survivalButton;
	@FXML
	private AnchorPane downloadInfoPane;
	@FXML
	private Text downloadInfo;
	@FXML
	private JFXProgressBar downloadProgress;
	@FXML
	private AnchorPane settingsPane;
	@FXML
	private Label saveText;
	@FXML
	private Label logoutText;
	@FXML
	private AnchorPane noInternet;
	@FXML
	private JFXCheckBox animationsCheckBox;
	@FXML
	private JFXCheckBox consoleCheckBox;
	@FXML
	private JFXTextField backgroundField;
	@FXML
	private JFXSlider ramSetting;
	@FXML
	private StackPane stackpane;
	@FXML
	private Label noInternetError;
	@FXML
	private AnchorPane addonsPane;
	@FXML
	private Button addonCloseBtn;
	@FXML
	private Label addonsCloseText;
	@FXML
	private Pane contentPane;
	@FXML
	private JFXTextArea console;
	
	@FXML
	private void addons(ActionEvent e) {
		
		try {
			addonsLoad();
		} catch (JSONException a) {
			// TODO Auto-generated catch block
			a.printStackTrace();
		} catch (IOException a) {
			// TODO Auto-generated catch block
			a.printStackTrace();
		}
		
		Logger.log(LogType.info(), e.toString());
		addonsPane.setVisible(true);
       	Timeline addonsAnimate = animations.leftOpen().build(JFXAnimationTemplates::buildTimeline, addonsPane);
    	Timeline mainBlur = animations.blur().build(JFXAnimationTemplates::buildTimeline, mainPane);
    	mainBlur.play();
    	addonsAnimate.play();
	}
	
	@FXML
	private void addonCloseBtn(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		addonsPane.setVisible(true);
       	Timeline addonsAnimate = animations.leftClose().build(JFXAnimationTemplates::buildTimeline, addonsPane);
    	Timeline mainBlur = animations.unBlur().build(JFXAnimationTemplates::buildTimeline, mainPane);
    	mainBlur.play();
    	addonsAnimate.play();
    	addonsAnimate.setOnFinished(a -> hideAddons());

	}
	
	@FXML
	private void news(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		loadUrl("https://api.technicworld.pl/?site=lglowna" + "&accesstoken=" + settings.getToken());
	}
	@FXML
	private void play(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		if (isPlayable) {
			try {
				//System.out.println("NO");
				runMinecraft();
			} catch (JSONException | IllegalAccessException | IllegalArgumentException | InvocationTargetException
					| IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		}
	}
	@FXML
	private void settingsBTN(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		settingsPane.setVisible(true);
       	Timeline settingsAnimate = animations.leftOpen().build(JFXAnimationTemplates::buildTimeline, settingsPane);
    	Timeline mainBlur = animations.blur().build(JFXAnimationTemplates::buildTimeline, mainPane);
    	mainBlur.play();
    	settingsAnimate.play();
		
	}
	@FXML
	private void saveSettings(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		settings.setRam(String.valueOf(ramSetting.getValue()));
		settings.setAnimations(animationsCheckBox.isSelected());
		settings.setConsole(consoleCheckBox.isSelected());
		settings.saveSettings();
    	Timeline settingsAnimate = animations.leftClose().build(JFXAnimationTemplates::buildTimeline, settingsPane);
    	Timeline mainBlur = animations.unBlur().build(JFXAnimationTemplates::buildTimeline, mainPane);
    	mainBlur.play();
    	settingsAnimate.play();
    	settingsAnimate.setOnFinished(a -> hideSettings());
	}
	
	private void hideSettings() {
		settingsPane.setVisible(false);
	}
	
	private void hideAddons() {
		addonsPane.setVisible(false);
	}
	
	@FXML
	private void logoutBtn(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
	}
	@FXML
	private void modpacks(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		if (isPlayable) {
			openPackSelectionMenu();
			isPlayable = false;
		}
	}	
		
	@FXML
	private void playAnim(MouseEvent event) {
		Timeline timeline = animations.fadeInBTN().build(JFXAnimationTemplates::buildTimeline, playText);
		timeline.play();
	}
	
	@FXML
	private void playExit(MouseEvent event) {
		Timeline timeline = animations.fadeOutBTN().build(JFXAnimationTemplates::buildTimeline, playText);
		timeline.play();
	}
	
	@FXML
	private void addonCloseAnim(MouseEvent event) {
		Timeline timeline = animations.fadeInBTN().build(JFXAnimationTemplates::buildTimeline, addonsCloseText);
		timeline.play();
	}
	
	@FXML
	private void addonCloseExit(MouseEvent event) {
		Timeline timeline = animations.fadeOutBTN().build(JFXAnimationTemplates::buildTimeline, addonsCloseText);
		timeline.play();
	}
	
	@FXML
	private void loginAnim(MouseEvent event) {
		Timeline timeline = animations.fadeInBTN().build(JFXAnimationTemplates::buildTimeline, loginButtonText);
		timeline.play();

	}
	
	@FXML
	private void loginExit(MouseEvent event) {
		Timeline timeline = animations.fadeOutBTN().build(JFXAnimationTemplates::buildTimeline, loginButtonText);
		timeline.play();
	}
	@FXML
	private void saveAnim(MouseEvent event) {
		Timeline timeline = animations.fadeInBTN().build(JFXAnimationTemplates::buildTimeline, saveText);
		timeline.play();

	}
	
	@FXML
	private void saveExit(MouseEvent event) {
		Timeline timeline = animations.fadeOutBTN().build(JFXAnimationTemplates::buildTimeline, saveText);
		timeline.play();
	}
	@FXML
	private void logoutAnim(MouseEvent event) {
		Timeline timeline = animations.fadeInBTNlogout().build(JFXAnimationTemplates::buildTimeline, logoutText);
		timeline.play();

	}
	
	@FXML
	private void logoutExit(MouseEvent event) {
		Timeline timeline = animations.fadeOutBTNlogout().build(JFXAnimationTemplates::buildTimeline, logoutText);
		timeline.play();
	}
	@FXML
	private void settingsAnim(MouseEvent event) {
		Timeline timeline = animations.fadeInBTN().build(JFXAnimationTemplates::buildTimeline, settingsICON);
		timeline.play();
	}
	
	@FXML
	private void settingsExit(MouseEvent event) {
		Timeline timeline = animations.fadeOutBTN().build(JFXAnimationTemplates::buildTimeline, settingsICON);
		timeline.play();
	}
	
	@FXML
	private void initialize() throws MalformedURLException, IOException {
		if(isServerOnline()) {
			runLauncher();
		}
	}
	
	private void runLauncher() {
		animationsCheckBox.setSelected(settings.getAnimations());
		consoleCheckBox.setSelected(settings.getConsole());
		ramInit();
		
		menuLeftPane.setVisible(true);
		loginLoading.setVisible(true);
		loadingText.setVisible(true);
		loginFormPane.setVisible(false);
		GaussianBlur blur = new GaussianBlur(8);
		mainPane.setEffect(blur);
		Runnable thread = new Runnable() {
			public void run() {
				Platform.runLater(new Runnable() {
		            @Override public void run() {
		        		checkToken();
			        }
				});
			}
		};
		ExecutorService executor = Executors.newCachedThreadPool();
	    executor.submit(thread);
	}
	
	private void ramInit() {
        long memorySize = ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getTotalPhysicalMemorySize()/1024/1024;
        Double memsize = (double) memorySize;
        Logger.log(LogType.info(), "Ilość pamięci ram w komputerze="+memsize+" MB");
        
		ramSetting.setMax(Double.parseDouble(String.format("%.0f", (memsize/1024))));

		rammc = Double.parseDouble(String.format("%.0f", ramSetting.getValue()*1024));
       
		ramSetting.valueProperty().addListener(new ChangeListener<Number>() {
			public void changed(ObservableValue<? extends Number> ov, Number old_val, Number new_val) {
                rammc = Double.parseDouble(String.format("%.0f", ramSetting.getValue()*1024));
			}
		});
		ramSetting.setOnMouseReleased(event -> {
			Logger.log(LogType.info(), "Ramu dla minecraft: "+rammc.toString()+"MB");
        });
       
		rame = Double.parseDouble(settings.getRam());
		if(settings.getFirstRun()) {
	        int pRam = Integer.parseInt(String.format("%.0f", (memsize/1024)));
			String zalRam = "0";
			switch(pRam) {
				case(1):
					zalRam = "brak";
					break;
				case(2):
					zalRam = "brak";
					break;
				case(3):
					zalRam = "brak";
					break;
				case(4):
					zalRam = "2";
					break;
				case(5):
					zalRam = "2";
					break;
				case(6):
					zalRam = "3";
					break;
				case(7):
					zalRam = "4";
					break;
				case(8):
					zalRam = "4";
					break;
				case(9):
					zalRam = "4";
					break;
				case(10):
					zalRam = "5";
					break;
				case(11):
					zalRam = "5";
					break;
				case(12):
					zalRam = "6";
					break;
				case(13):
					zalRam = "6";
					break;
				case(14):
					zalRam = "6";
					break;
				case(15):
					zalRam = "7";
					break;
				case(16):
					zalRam = "7";
					break;
			    default:
			    	if(pRam >= 17) {
			    		zalRam = "10";
			    	} else if (pRam <= 1) {
			    		zalRam = "brak";
			    	}
			        break;
			}
			if (zalRam.equals("brak")) {
				alert("Houston mamy problem", "Niestety twój komputer może nie uruchomić paczki :( \nPosiadasz zbyt mało ramu w komputerze,\nminimalna ilość dla paczki to: 3GB");
				ramSetting.setValue(Double.valueOf(zalRam));
			} else {
				alert("Ustawiono zalecaną ilość ramu dla minecraft!", "Minimalna ilość ramu dla paczki to 3GB.\nPrzypisaliśmy: "+zalRam+"GB");
				ramSetting.setValue(Double.valueOf(zalRam));
			}
		} else {
			ramSetting.setValue(rame);
		}
		
		
	}
	
	private Boolean isServerOnline() {
		try {
	       	URL url = new URL("https://technicworld.pl");
	        URLConnection connection = url.openConnection();
	       	connection.connect();
	        noInternet.setVisible(false);
	        connection.getInputStream().close();
	        return true;
		} catch (MalformedURLException e) {
			noInternetError.setText(e.toString());
	        noInternet.setVisible(true);
	        
	        return false;
		} catch (IOException e) {
			noInternetError.setText(e.toString());
	        noInternet.setVisible(true);
	        return false;
		}
	}
	
	private void openPackSelectionMenu() {
		modpackPane.setTranslateX(-1 * modpackPane.getBoundsInParent().getWidth());
		menuPackLeftPane.setVisible(true);
    	Timeline packAnimate = animations.leftOpen().build(JFXAnimationTemplates::buildTimeline, modpackPane);
    	Timeline mainBlur = animations.blur().build(JFXAnimationTemplates::buildTimeline, mainPane);
    	mainBlur.play();
		packAnimate.play();
	}
	
	//PACK ----------------------------------------------------------------------------------------------------------------------->	

	private void checkModpack() {
		if(settings.getPack().equals("select")) {
			mainPane.setDisable(true);
			openPackSelectionMenu();
		} else {
			modpackCheck();
		}
	}
	
	@FXML
	private void skyblockButton(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		settings.setPack("skyblock");
		settings.saveSettings();
		Main.changeStageName("TechnicWorld | Skyblock");
    	Timeline packAnimate = animations.leftClose().build(JFXAnimationTemplates::buildTimeline, modpackPane);
    	Timeline mainBlur = animations.unBlur().build(JFXAnimationTemplates::buildTimeline, mainPane);
    	mainBlur.play();
    	packAnimate.play();
    	packAnimate.setOnFinished(a -> modpackSelected());
    	
	}
	@FXML
	private void survivalButton(ActionEvent e) {
		Logger.log(LogType.info(), e.toString());
		settings.setPack("survival");
		settings.saveSettings();
		Main.changeStageName("TechnicWorld | Survival");
    	Timeline packAnimate = animations.leftClose().build(JFXAnimationTemplates::buildTimeline, modpackPane);
    	Timeline mainBlur = animations.unBlur().build(JFXAnimationTemplates::buildTimeline, mainPane);
    	mainBlur.play();
    	packAnimate.play();
    	packAnimate.setOnFinished(a -> modpackSelected());

	}	
	
	private void modpackSelected() {
		checkModpack();
		mainPane.setDisable(false);
		leftPackPaneSetVisible(false);
	}
	
	private void leftPackPaneSetVisible(Boolean t) {
		menuPackLeftPane.setVisible(t);
	}
	
	private void hideDownloadPane() {
    	Timeline downloadAnimate = animations.bottomClose().build(JFXAnimationTemplates::buildTimeline, downloadInfoPane);
    	downloadAnimate.setOnFinished(a -> hideDP());
    	downloadAnimate.play();
    	
	}
	
	private void hideDP() {
		downloadInfoPane.setVisible(false);
		mainPane.setDisable(false);
	}
	
	private void showDownloadPane() {
		downloadInfoPane.setTranslateY(1 * modpackPane.getBoundsInParent().getHeight());
		downloadInfoPane.setVisible(true);
    	Timeline downloadAnimate = animations.bottomOpen().build(JFXAnimationTemplates::buildTimeline, downloadInfoPane);
    	downloadAnimate.play();    	
	}
	
	private void modpackCheck() {
	    modsPath = settings.getWorkingDir() + slash + settings.getPack() + slash + "Minecraft" + slash + "mods";
	    minecraftPath = settings.getWorkingDir() + slash + settings.getPack() + slash + "Minecraft";
	    urlModsPath = "https://api.technicworld.pl/api/modpack-" + settings.getPack();
	    urlAddonsList = "https://api.technicworld.pl/api/addons_" + settings.getPack() + ".json";
	    urlModsList = "https://api.technicworld.pl/api/mods-" + settings.getPack() + ".json";
	    packVersion = settings.getPackVersion();
	    downloadIcon.setGlyphName("AUTORENEW");
    	downloadInfo.setText("Przygotowywanie paczki do gry...");
  		downloadProgress.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);       
  		showDownloadPane();
  		
		Runnable thread = new Runnable() {
			public void run() {
				try {
					Logger.log(LogType.info(), "Pobieram json'a");
					getModsJson();
					Logger.log(LogType.info(), "Pobieram mody");
					if(startCheckingAndDownloadMods(urlModsPath, modsPath) == true) {
						try {
							downloadIcon.setGlyphName("AUTORENEW");
							Logger.log(LogType.info(), "Sprawdzam mody");
							if(!checkMods(urlModsPath, modsPath)) {
								Logger.log(LogType.error(), "Wystąpił nieznany problem podczas sprawdzania modów!");
							}
							Logger.log(LogType.info(), "Sprawdzam config ("+packVersion+" -> "+settings.getPackVersion()+")");
							if (!settings.getPackVersion().equals(packVersion)) {
								Logger.log(LogType.info(), "Pobieram config ("+packVersion+" -> "+settings.getPackVersion()+")");
								if (downloadConfigs(new URL("https://api.technicworld.pl/api/config-"+settings.getPack()+".zip"), new File(minecraftPath))) {
									downloadInfo.setText("Paczka jest gotowa do gry :)");
									downloadIcon.setGlyphName("GAMEPAD");
									Logger.log(LogType.info(), "Paczka jest gotowa do gry :)!");
						            javafx.application.Platform.runLater( () -> hideDownloadPane());
						            settings.setPackVersion(packVersion);
						            settings.saveSettings();
						            isPlayable = true;
								}
							} else {
								downloadIcon.setGlyphName("GAMEPAD");
								downloadInfo.setText("Paczka jest gotowa do gry :)");
								Logger.log(LogType.info(), "Paczka jest gotowa do gry :)!");
					            javafx.application.Platform.runLater( () -> hideDownloadPane());
					            isPlayable = true;
							}
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else {
						Logger.log(LogType.info(), "Wystąpił nieznany problem podczas sprawdzania modów!");
					}
				} catch (JSONException | IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		};
		ExecutorService executor = Executors.newCachedThreadPool();
	    executor.submit(thread);
		
	}
	
	private boolean checkMods(String modsUrl, String modspath) throws IOException {
        // update progress bar
        Platform.runLater(new Runnable() {;

            @Override
            public void run() {
            	downloadInfo.setText("Sprawdzam mody...");
          		downloadProgress.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);       
            }
        });
		try {
			File folder = new File(modspath);
		    File[] listOfFiles = folder.listFiles();
		    String modsStr = "";
			for (modsListClass mods : modsList) {
				modsStr+=mods.getName();
				if (mods.isAddon()) {
					modsStr+=mods.getName()+".disable";
				}
				if(mods.isAddon()) {
					String modStr = modspath+"/"+mods.getName().replace("|", "//");
					File mod = new File(modStr);
					String modStrAddon = modspath+"/"+mods.getName().replace("|", "//")+".disable";
					File modAddon = new File(modStrAddon);
					if (!modAddon.exists() && !mod.exists()) {
						downloadMod(new URL(modsUrl+"/"+mods.getName().replace("|", "/").replaceAll(" ", "%20")), modspath+slash+mods.getName().replace("|", slash), mods.getName(), new File(modspath+slash+"1.7.10"), new File(modspath), mods.isAddon(), 0, 0);
					} else {
						try {
							if (!getModHash(modStrAddon).contains(mods.getHash().toLowerCase()) && !getModHash(modStr).contains(mods.getHash().toLowerCase())) {
								downloadMod(new URL(modsUrl+"/"+mods.getName().replace("|", "/").replaceAll(" ", "%20")), modspath+slash+mods.getName().replace("|", slash), mods.getName(), new File(modspath+slash+"1.7.10"), new File(modspath), mods.isAddon(), 0, 0);
							}
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				} else {
					String modStr = modspath+"/"+mods.getName().replace("|", "//");
					File mod = new File(modStr);
					if (mod.exists()) {
						try {
							if (!getModHash(modStr).contains(mods.getHash().toLowerCase())) {
								downloadMod(new URL(modsUrl+"/"+mods.getName().replace("|", "/").replaceAll(" ", "%20")), modspath+slash+mods.getName().replace("|", slash), mods.getName(), new File(modspath+slash+"1.7.10"), new File(modspath), mods.isAddon(), 0, 0);
							}
						} catch (NoSuchAlgorithmException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					} else {
						downloadMod(new URL(modsUrl+"/"+mods.getName().replace("|", "/").replaceAll(" ", "%20")), modspath+slash+mods.getName().replace("|", slash), mods.getName(), new File(modspath+slash+"1.7.10"), new File(modspath), mods.isAddon(), 0, 0);
					}
				}
			}
		    for (int i = 0; i < listOfFiles.length; i++) {
		    	 if (listOfFiles[i].isFile()) {
					 if(!modsStr.contains(listOfFiles[i].getName()) == true) {
						 Logger.log(LogType.info(), listOfFiles[i].getName()+", usuwanie...");
						 Path pat = Paths.get(modspath+slash+listOfFiles[i].getName());
		            	 Files.delete(pat);
		            	 Logger.log(LogType.info(), "Usunięto!");
		    		 }
		         }
		    }
		} finally {
			return true;
		}
	}
	
    private boolean startCheckingAndDownloadMods(String modsUrl, String modspath) throws MalformedURLException {
            for (modsListClass mods : modsList) {
                if (mods.isAddon()) {
                    String modStr = String.valueOf(modspath) + "/" + mods.getName().replace("|", slash);
                    File mod = new File(modStr);
                    String modStrAddon = String.valueOf(modspath) + "/" + mods.getName().replace("|", slash) + ".disable";
                    File modAddon = new File(modStrAddon);
                    if (!modAddon.exists() && !mod.exists()) {
                    	downloadMod(new URL(String.valueOf(modsUrl) + "/" + mods.getName().replace("|", "/").replaceAll(" ", "%20")), String.valueOf(modspath) + slash + mods.getName().replace("|", slash), mods.getName(), new File(String.valueOf(modspath) + slash + "1.7.10"), new File(modspath), mods.isAddon(), mods.getId(), modsList.size());                     
                    }
                    else {
                        try {
                            if (getModHash(modStrAddon).contains(mods.getHash().toLowerCase()) || getModHash(modStr).contains(mods.getHash().toLowerCase())) {
                                continue;
                            }
                        	downloadMod(new URL(String.valueOf(modsUrl) + "/" + mods.getName().replace("|", "/").replaceAll(" ", "%20")), String.valueOf(modspath) + slash + mods.getName().replace("|", slash), mods.getName(), new File(String.valueOf(modspath) + slash + "1.7.10"), new File(modspath), mods.isAddon(), mods.getId(), modsList.size());
                            
                        }
                        catch (NoSuchAlgorithmException e) {
                            e.printStackTrace();
                        }
                        catch (FileNotFoundException e2) {
                            e2.printStackTrace();
                        }
                        catch (IOException e3) {
                            e3.printStackTrace();
                        }
                    }
                }
                else {
                    String modStr = String.valueOf(modspath) + "/" + mods.getName().replace("|", slash);
                    File mod = new File(modStr);
                    if (mod.exists()) {
                        try {
                            if (getModHash(modStr).contains(mods.getHash().toLowerCase())) {
                                continue;
                            }
                        		downloadMod(new URL(String.valueOf(modsUrl) + "/" + mods.getName().replace("|", "/").replaceAll(" ", "%20")), String.valueOf(modspath) + slash + mods.getName().replace("|", slash), mods.getName(), new File(String.valueOf(modspath) + slash + "1.7.10"), new File(modspath), mods.isAddon(), mods.getId(), modsList.size());
                        }
                        catch (NoSuchAlgorithmException e4) {
                            e4.printStackTrace();
                        }
                        catch (FileNotFoundException e5) {
                            e5.printStackTrace();
                        }
                        catch (IOException e6) {
                            e6.printStackTrace();
                        }
                    }
                    else {
                    	downloadMod(new URL(String.valueOf(modsUrl) + "/" + mods.getName().replace("|", "/").replaceAll(" ", "%20")), String.valueOf(modspath) + slash + mods.getName().replace("|", slash), mods.getName(), new File(String.valueOf(modspath) + slash + "1.7.10"), new File(modspath), mods.isAddon(), mods.getId(), modsList.size());
      	
                    }
                }
            }
        
        return true;
    }
    
    private boolean getModsJson() throws JSONException, IOException {
        JSONObject json = jsonReader.readJsonFromUrl(urlModsList);
        int jsonSize = json.getJSONArray("mods").length();
        packVersion = json.getString("version");
        for (int i = 0; i < jsonSize; ++i) {
            JSONObject jsonObject = json.getJSONArray("mods").getJSONObject(i);
            modsListClass arrayMods = new modsListClass();
            arrayMods.setId(i);
            arrayMods.setName(jsonObject.get("name").toString());
            arrayMods.setAddon(jsonObject.get("addon").toString());
            arrayMods.setHash(jsonObject.get("md5").toString().toLowerCase());
            modsList.add(arrayMods);
            mods += 1;
        }
        return true;
    }
	
	//</PACK --------------------------------------------------------------------------------------------------------------------->	
	
	
	//[+]  \
//		   | Pozdrawiam dekompilatorów! :)
	//[-]  /

	
	//LOGIN ----------------------------------------------------------------------------------------------------------------------->	
	
	private void checkToken() {
		loginLoading.setVisible(true);
		loadingText.setVisible(true);
		loginFormPane.setVisible(false);
		mainPane.setDisable(true);
        try {
			JSONObject json = jsonReader.readJsonFromUrl("https://api.technicworld.pl/index.php?api=check&token=" + settings.getToken());
	        if (json.get("token").equals("succ")) {
	        	//Token ważny
	        	loginLoading.setVisible(true);
	        	browserInit(); //Wczytanie przeglądarki
	    		loadingText.setVisible(true);
	    		loginFormPane.setVisible(false);
	    		mainPane.setDisable(false);
            	Timeline loginAnimate = animations.leftClose().build(JFXAnimationTemplates::buildTimeline, loginPane);
            	Timeline mainBlur = animations.unBlur().build(JFXAnimationTemplates::buildTimeline, mainPane);
            	mainBlur.play();
        		loginAnimate.play();
        		loginAnimate.setOnFinished(e -> modpackInit());
        		settings.setUsername(json.get("username").toString());
        		nick.setText(settings.getUsername());
        		if(json.get("rank").toString().equals("Wlasciciel")) {
        			rankTxt.setText("#Właścicel");
        		} else if(json.get("rank").toString().equals("default") || json.get("rank").toString().equals("Default")) {
        			rankTxt.setText("#Gracz");
        		} else if(json.get("rank").toString().isEmpty()) {
            		rankTxt.setText("#Gracz");
        		} else if(json.get("rank").toString().equals("admin")) {
            		rankTxt.setText("#Administrator");
        		} else {
            		rankTxt.setText("#" + json.get("rank").toString());
        		}
	        } else if (settings.getToken().contentEquals("-1")) {
	        	//Nigdy nie zalogowano
	        	loginLoading.setVisible(false);
	    		loadingText.setVisible(false);
	    		loginFormPane.setVisible(true);
	    		mainPane.setDisable(true);
            	Timeline loginAnimate = animations.leftOpen().build(JFXAnimationTemplates::buildTimeline, loginPane);
            	Timeline mainBlur = animations.blur().build(JFXAnimationTemplates::buildTimeline, mainPane);
            	mainBlur.play();
            	loginAnimate.setOnFinished(e -> leftPaneSetVisible(true));
        		loginAnimate.play();
        		
	        } else {
	        	//Wylogowano
	        	loginLoading.setVisible(false);
	    		loadingText.setVisible(false);
	    		loginFormPane.setVisible(true);
	            Logger.log(LogType.warn(), "Wylogowano!");
	    		mainPane.setDisable(true);
            	Timeline loginAnimate = animations.leftOpen().build(JFXAnimationTemplates::buildTimeline, loginPane);
            	Timeline mainBlur = animations.blur().build(JFXAnimationTemplates::buildTimeline, mainPane);
            	mainBlur.play();
            	loginAnimate.setOnFinished(e -> leftPaneSetVisible(true));
        		loginAnimate.play();
        		
	        }
		} catch (JSONException | IOException e) {
			Logger.log(LogType.error(), e.toString());
		}
	}
	
	private void modpackInit() {
		checkModpack();
		isPlayable = false;
		leftPaneSetVisible(false);
	}
	
	private void leftPaneSetVisible(Boolean t) {
		menuLeftPane.setVisible(t);
	}
	
	@FXML
	private void loginButton(ActionEvent e) {
		loginLoading.setVisible(true);
		Logger.log(LogType.info(), e.toString());
		String login = loginField.getText();
		String pass = passwordField.getText();
		try {
			if (checklogin(login, pass)) {
				checkToken();
			}
		} catch (JSONException | IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
	}	

    private boolean checklogin(String user, String pass) throws JSONException, IOException {
        resetColors();
        JSONObject json = jsonReader.readJsonFromUrlPost("https://api.technicworld.pl/index.php?api=login", "login=" + user + "&pass=" + pass);
        Logger.log(LogType.info(), json.toString());
        if (!json.isNull("info")) {
            Logger.log(LogType.info(), "Nazwa użytkownika: " + json.get("username"));
            settings.setToken(json.getString("success"));
            settings.saveSettings();
            return true;
        }
        Logger.log(LogType.error(), json.get("error").toString());
        if (((String)json.get("function")).equals("login")) {
            loginText.setText("Sprawdź pole z loginem!");
            loginField.setUnFocusColor(Color.RED);
        }
        else if (((String)json.get("function")).equals("password")) {
        	loginText.setText("Sprawdź pole z hasłem!");
            passwordField.setUnFocusColor(Color.RED);
        }
        else if (json.get("msg").toString().contains("zablokowane")) {
        	loginText.setText("Konto zostało zablokowane!\nSpróbuj ponownie za jakiś czas\n lub skontaktuj się z administracją!");
        }
        else {
        	loginText.setText("Podałeś zły login lub hasło!");
            loginField.setUnFocusColor(Color.RED);
            passwordField.setUnFocusColor(Color.RED);
        }
        loginLoading.setVisible(false);
        return false; 
    }
    
    private void resetColors() {
        Color normal = new Color(0.77, 0.77, 0.77, 1.0);
        loginField.setUnFocusColor(normal);
        passwordField.setUnFocusColor(normal);
    }
    
	//</LOGIN --------------------------------------------------------------------------------------------------------------------->
		
		//[+]  \
// 			   | Pozdrawiam dekompilatorów! :)
		//[-]  /
	
	//Browser --------------------------------------------------------------------------------------------------------------------->
    
	private String currentURL;
	private void browserInit() {
		WebEngine engine = webBrowser.getEngine();

		Runnable thread = new Runnable() {
			public void run() {
				Platform.runLater(new Runnable() {
		            @SuppressWarnings("unchecked")
					@Override public void run() {
		                engine.setUserAgent(settings.getUserAgent());
						webBrowser.setContextMenuEnabled(false);				        
				
						engine.getLoadWorker().stateProperty().addListener((observable, oldValue, newValue) -> {
				            if (Worker.State.SCHEDULED.equals(newValue)) {
				            	checkBrowser();
				            	String url = engine.getLocation();
				                if(url.contains("api.technicworld.pl")) {
					                if(!url.contains("&accesstoken=" +settings.getToken())) {
					                    engine.getLoadWorker().cancel();
					    		        loadUrl(url + "&accesstoken=" + settings.getToken());
					                } else {
					                    browserProgress.progressProperty().bind(engine.getLoadWorker().progressProperty());
					                }
					                url = null;
				                } else {  
				                    engine.getLoadWorker().cancel();
				                }
				
				            } 
				            if (Worker.State.SUCCEEDED.equals(newValue)) {
				            	String url = engine.getLocation();
				            	if(!url.contains("api.technicworld.pl")) {
				                    engine.getLoadWorker().cancel();
				    		        loadUrl(currentURL + "&accesstoken=" + settings.getToken());
				            	}
				    			browserProgress.progressProperty().unbind();
				    			url = null;
				    			browserProgress.setVisible(false);
	                            webBrowser.setVisible(true);
			    		        Runtime.getRuntime().gc(); 
				            }
				            if (Worker.State.CANCELLED.equals(newValue)) {
				    			browserProgress.progressProperty().unbind();
				            }
				            if (Worker.State.FAILED.equals(newValue)) {
				    			browserProgress.progressProperty().unbind();
				            }
				        });
						WebViewHyperlinkListener activationCancelingListener  = event -> {
							if(!(event.getURL() == null)) {
						        loadUrl(event.getURL() + "&accesstoken=" + settings.getToken());
							}
							return false;
						};
						WebViews.addHyperlinkListener(webBrowser, activationCancelingListener, HyperlinkEvent.EventType.ACTIVATED);
						loadUrl("https://api.technicworld.pl/?site=lglowna" + "&accesstoken=" + settings.getToken());
		            }
		        });
	        }
	    };
		ExecutorService executor = Executors.newCachedThreadPool();
	    executor.submit(thread);
	}
	
    public void loadUrl(String URL) {
    	WebEngine engine = webBrowser.getEngine();

    	if (!URL.contains("api.technicworld.pl")) {
    		Browser.browseURL(URL);
    	} else {
	        currentURL = URL;
	        engine.setUserAgent(settings.getUserAgent());
	        engine.setJavaScriptEnabled(true);
	        engine.load(URL);
    	}
    }
    
    @SuppressWarnings("unchecked")
	public void checkBrowser() {
        browserProgress.setVisible(true);
        webBrowser.setVisible(false);
        browserProgress.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);
    }
    
    //</ Browser ------------------------------------------------------------------------------------------------------------------/>
    //DOWNLOADER ------------------------------------------------------------------------------------------------------------------->

    public Boolean downloadMod(URL url, String path, String modname, File modsPath, File otherModsPath, Boolean isAddon, int modID, int modsSize) {
    	downloadIcon.setGlyphName("DOWNLOAD");
		if (isAddon) {
			path +=".disable";
		}
		if (!otherModsPath.exists()) {
			Logger.log(LogType.info(), "Tworzę folder: " + otherModsPath.getName());
			boolean result = false;	
		    try{
		       	otherModsPath.mkdirs();
		        result = true;
		    } catch(SecurityException se){
		       	Logger.log(LogType.error(), "Wystąpił błąd przy tworzeniu folderu!\n"+se);
		    }        
		    if(result) {
		    	Logger.log(LogType.info(), "Stworzono folder!");
		    }
		}
		
        javafx.application.Platform.runLater( () -> downloadInfo.setText("Pobieram ("+modID+"/"+modsSize+"): " + modname));

		Logger.log(LogType.info(), "Pobieram ("+modID+"/"+modsSize+"): " + modname);
			 
		download(url, path);
             
		Logger.log(LogType.info(), "Pobrano!");
		
        return true;
	}
	
    public String getModHash(String mod) throws NoSuchAlgorithmException, FileNotFoundException, IOException {
        File folder = new File(mod);
        if (!folder.exists()) {
            return "false";
        }
        MessageDigest md = MessageDigest.getInstance("MD5");
        String digest = getDigest(new FileInputStream(mod), md, 2048);
        return digest.toLowerCase();
    }
    
    public String getDigest(InputStream is, MessageDigest md, int byteArraySize) throws NoSuchAlgorithmException, IOException {
        md.reset();
        final byte[] bytes = new byte[byteArraySize];
        int numBytes;
        while ((numBytes = is.read(bytes)) != -1) {
            md.update(bytes, 0, numBytes);
        }
        byte[] digest = md.digest();
        String result = new String(Hex.encodeHex(digest)).toUpperCase();
        return result;
    }
	
	public Boolean downloadConfigs(URL url, File path) throws IOException {
		javafx.application.Platform.runLater( () -> downloadIcon.setGlyphName("DOWNLOAD"));
        javafx.application.Platform.runLater( () -> downloadInfo.setText("Pobieram: konfiguracja"));

        if (!path.exists()) {
        	path.mkdirs();
        }
        
        archiveDownload(url, path);
		return true;
	}
	
    private File archiveDownload(URL url, File targetDir) throws IOException {
    	File zip = File.createTempFile("configs", ".zip", targetDir);
    	download(url, zip.toString());
        javafx.application.Platform.runLater( () -> downloadInfo.setText("Rozpakowywuję: konfiguracja"));
        javafx.application.Platform.runLater( () -> downloadProgress.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS));
        javafx.application.Platform.runLater( () -> downloadIcon.setGlyphName("FOLDER"));
    	return pl.B4GU5.Utils.unpackArchive.unpackZip(zip, targetDir);
    }
	
	private Boolean download(URL url, String path) {
        javafx.application.Platform.runLater( () -> downloadProgress.setProgress(0));

		try  {
			 HttpURLConnection httpsConnection = (HttpURLConnection) (url.openConnection());
	         httpsConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.95 Safari/537.11");
	         long completeFileSize = httpsConnection.getContentLength();
	         BufferedInputStream in = new BufferedInputStream(httpsConnection.getInputStream());
	         FileOutputStream fos = new FileOutputStream(path);
	         BufferedOutputStream bout = new BufferedOutputStream(fos, 1024);
	         byte[] data = new byte[1024];
	         long downloadedFileSize = 0;
	         int x = 0;
	         
	         while ((x = in.read(data, 0, 1024)) >= 0) {
	        	 double currentProgress;
	             downloadedFileSize += x;
	             currentProgress = downloadedFileSize / (double)completeFileSize * 100.0;
	             javafx.application.Platform.runLater( () -> downloadProgress.setProgress((currentProgress / 100.0)));

	             bout.write(data, 0, x);
	         }
	         bout.close();
	         in.close();
	         fos.close();
	         bout.close();
	         httpsConnection.disconnect();
	         data = null;
	         return true;
	    } catch (FileNotFoundException e) {
		     Logger.log(LogType.error(), "Wystąpił błąd podczas pobierania!\n"+e);
	    } catch (IOException e) {
		     Logger.log(LogType.error(), "Wystąpił błąd podczas pobierania!\n"+e);
	    }
        return true;
	}
    //Alert
	  private void alert(String title, String content) {
		  try {
		    BoxBlur boxblur = new BoxBlur(8,8,8);
		    mainPane.setEffect(boxblur);
		    JFXDialogLayout dialogContent = new JFXDialogLayout();
		    
		    dialogContent.setHeading(new Text(title));
		    
		    dialogContent.setBody(new Text(content));
		    
		    JFXButton close = new JFXButton("Okej");
		    close.setTextFill(Color.WHITE);
		    close.setStyle("-fx-background-color: #292b2c;");
		    
		    dialogContent.setActions(close);
		    
		    JFXDialog dialog = new JFXDialog(stackpane, dialogContent, JFXDialog.DialogTransition.CENTER);

		    close.setOnAction(actionEvent -> {
		    	dialog.close();
	        });

		    dialog.setOnDialogClosed(closeEvent -> {
		    	mainPane.setEffect(null);
		   });
		    dialog.autosize();
		    dialog.show();
		    
		  } catch(Exception e) {
			  Logger.log(LogType.info(), e.toString());
		  }
	    }
//ADDONS
		String ID = "null";
		double position = -77;
		double size0 = 77;
		public void addonsLoad() throws JSONException, IOException {
			ID = "null";
			position = -77;
			size0 = 77;
			contentPane.getChildren().clear();

	        Runnable updatethread = new Runnable() {
	        	public void run() {

					        try {
					            JSONObject json = jsonReader.readJsonFromUrl("https://api.technicworld.pl/api/addons-"+settings.getPack()+".json");
					            JSONArray arr = json.getJSONArray("mods");
					            String content = jsonReader.readJsonFromUrl("https://api.technicworld.pl/api/mods-"+settings.getPack()+".json").toString();
					            for (int i = 0; i < arr.length(); i++) {
					            	System.out.println(content);
					            	String nazwa = arr.getJSONObject(i).getString("dispname");
					            	String obrazek = arr.getJSONObject(i).getString("img");
					            	String ID = arr.getJSONObject(i).getString("name");
					            	if (content.contains(ID)) {
									Platform.runLater(new Runnable() {
									    @Override
								        public void run() {
									    	try {
												addViewPane(nazwa, obrazek, ID);
											} catch (IOException e) {
												// TODO Auto-generated catch block
												e.printStackTrace();
											}
								        }
								        
									});
					            	}
									try {
									    Thread.sleep(10);
									} catch(InterruptedException ex) {
									    Thread.currentThread().interrupt();
									}
					            }
							} catch (JSONException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}

			    }
			};
			ExecutorService executor = Executors.newCachedThreadPool();
		    executor.submit(updatethread);


		}
		public void addViewPane(String Nazwa0, String img, String ID0) throws IOException {
			
			System.out.println("Trwa dodawanie... Lokalizacja (Y): ");
			double size = contentPane.getHeight();

			System.out.println(size0);
		    pl.B4GU5.TW.addons vwP = new pl.B4GU5.TW.addons();
			contentPane.setPrefHeight(size0);
			
			FXMLLoader loader = new FXMLLoader(getClass().getResource("listPaneItem.fxml"));


		    loader.setController(vwP);

		    Pane view = (Pane) loader.load();
		    position += 77;
		    contentPane.getChildren().add(view);
		    view.setLayoutY(position);
					
			vwP.Nazwa(Nazwa0);
			vwP.Obrazek(img);
			vwP.ID(ID0);
			  Path p = Paths.get(System.getProperty("user.home")+slash+"TechnicWorld"+slash+settings.getPack()+slash+"Minecraft"+slash+"mods"+slash+ID0);
			  Path p2 = Paths.get(System.getProperty("user.home")+slash+"TechnicWorld"+slash+settings.getPack()+slash+"Minecraft"+slash+"mods"+slash+ID0+".disable");
			  System.out.println(p);
	          boolean enabled = Files.exists(p);
	          boolean disabled = Files.exists(p2);
	      
	  
	          if (enabled) {
	              System.out.println("File enabled");
	              vwP.aktywny();
	              System.out.println(vwP.active);
	              vwP.aktywuj();
	          } else if (disabled) {
	              System.out.println("File disabled");
	              vwP.nieaktywny();
	              System.out.println(vwP.active);
	              vwP.deaktywuj();;
	          } else {
	              System.out.println("File's status is unknown!");
	          }
			EventHandler<MouseEvent> paneOnMouseClicked = new EventHandler<MouseEvent>() {

			    public void handle(MouseEvent t) {
					ID = ID0;
			    	//load_content(Nazwa0, Autor0, Opis0, wersjaMC0, Obrazek0, Wersja0, Pobran0, Kiedy0, ID0, video0);
					if (!vwP.aktywny_infor()) {

						Path p3 = Paths.get(System.getProperty("user.home")+"//TechnicWorld//"+settings.getPack()+"//Minecraft//mods//"+ID0);
						Path p4 = Paths.get(System.getProperty("user.home")+"//TechnicWorld//"+settings.getPack()+"//Minecraft//mods//"+ID0+".disable");

						try {
							Files.move(p4, p3);
							vwP.aktywny();
							System.out.println(vwP.active);
							vwP.aktywuj();
						} catch (IOException e) {
							// TODO Auto-generated catch block
						
							e.printStackTrace();
							//erroralert(e);
						}
					} else if (vwP.aktywny_infor()) {

						Path p3 = Paths.get(System.getProperty("user.home")+"//TechnicWorld//"+settings.getPack()+"//Minecraft//mods//"+ID0);
						Path p4 = Paths.get(System.getProperty("user.home")+"//TechnicWorld//"+settings.getPack()+"//Minecraft//mods//"+ID0+".disable");

						try {
							Files.move(p3, p4);
							vwP.nieaktywny();
							System.out.println(vwP.active);
							vwP.deaktywuj();;
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							//erroralert(e);
						}
					}
					
					t.consume(); // consume event -> no further propagation
			    
			    	}
			    };


			view.addEventHandler(MouseEvent.MOUSE_CLICKED, paneOnMouseClicked);
			size0 += 77;

		}
		//Minecraft
		String mcver = "1.12.2";
		String forgever = "1.12.2-14.23.5.2838";
		String line = null;
	    Method memorySize = null;
	    OperatingSystemMXBean os = null;

		private void runMinecraft() throws JSONException, IOException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
			if (isPlayable) {
				isPlayable = true;
				downloadInfo.setText("Przygotowanie do uruchomienia minecraft...");
          		downloadProgress.setProgress(ProgressIndicator.INDETERMINATE_PROGRESS);
        		downloadIcon.setGlyphName("FLASH");	
				showDownloadPane();
				
				int sett = (int) ramSetting.getValue();
			  	String settt = Integer.toString(sett);
			  	System.out.println(sett);
			  	settings.setRam(settt);
			  	settings.saveSettings();
			  	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("HH:mm:ss");
				LocalDateTime now = LocalDateTime.now();
				String memsize = String.valueOf(ramSetting.getMax());
				String javaPath = Paths.get(System.getProperty("java.home"), "bin", OS.getCURRENT() == OS.WINDOWS ? "java.exe" : "java").toString();
				console.appendText("============================[| SPECYFIKACJA KOMPUTERA |]============================\r\n" + 
			  			"Uruchomiono minecraft o "+dtf.format(now)+"\r\n" + 
			  			"Uruchomiono paczkę: "+settings.getPack()+" v"+settings.getPackVersion()+"\r\n" +
			  			"Przypisano ramu: "+settings.getRam()+"GB\r\n" + 
			  			"Ramu w komputerze: "+memsize+"GB\r\n" + 
			  			"Ilość rdzeni procesora: "+Runtime.getRuntime().availableProcessors()+"\r\n" + 
			  			"Architektura os: "+System.getProperty("os.arch")+"\r\n" +
			  			"System operacyjny: "+System.getProperty("os.name")+"\r\n" + 
			  			"ścieżka folderu minecraft: "+System.getProperty("user.home")+"/TechnicWorld/"+settings.getPack()+"/Minecraft"+"\r\n" + 
			  			"ścieżka javy: "+javaPath+"\r\n" + 
			  			"==================================[| MINECRAFT |]==================================\r\n");
				try {
					
			        Runnable updatethread = new Runnable() {
			            public void run() {


			        

							 LaunchTask task = new LaunchTaskBuilder()
										
										.setCachesDir(System.getProperty("user.home")+"/TechnicWorld/"+settings.getPack()+"/Minecraft/mc-files") //Directory to cache stuff in, copies caches from .minecraft (and verifies)
										
										//.setMinecraftVersion("1.7.10") //Set vanilla version
										//OR
										.setForgeVersion(mcver, forgever) //Minecraftforge version
										
										.setInstanceDir(System.getProperty("user.home")+"/TechnicWorld/"+settings.getPack()+"/Minecraft") //Minecraft directory
										
										.setUsername(settings.getUsername()) //Username for offline
										.setOffline() //Offline mode
										
										.build(); //Build LaunchTask
								        Runnable updatethread = new Runnable() {
								            public void run() {
													Double a = (double) 0;
													while (a<100) {
														a = task.getCompletedPercentage();
								                          Platform.runLater(new Runnable() {;
								                          
							                              @Override
							                              public void run() {

							                  				downloadInfo.setText("Uruchamiam minecraft...");
							                          		downloadProgress.setProgress(task.getCompletedPercentage()/100);
							                        		downloadIcon.setGlyphName("AUTORENEW");	
							                              }
							                          });
													}
								            }};
										    new Thread(updatethread).
			
										    start();
										LaunchSpec spec = task.getSpec();
										spec.getJvmArgs().add("-mx"+settings.getRam()+"G");
										spec.getJvmArgs().add("-XX:InitiatingHeapOccupancyPercent=10");
										spec.getJvmArgs().add("-XX:AllocatePrefetchStyle=1");
										spec.getJvmArgs().add("-XX:+UseSuperWord");
										spec.getJvmArgs().add("-XX:+OptimizeFill");
										spec.getJvmArgs().add("-XX:LoopUnrollMin=4");
										spec.getJvmArgs().add("-XX:LoopMaxUnroll=16");
										spec.getJvmArgs().add("-XX:+UseLoopPredicate");
										spec.getJvmArgs().add("-XX:+RangeCheckElimination");
										spec.getJvmArgs().add("-XX:+CMSCleanOnEnter");
										spec.getJvmArgs().add("-XX:+EliminateLocks");
										spec.getJvmArgs().add("-XX:+DoEscapeAnalysis");
										spec.getJvmArgs().add("-XX:+TieredCompilation");
										spec.getJvmArgs().add("-XX:+UseCodeCacheFlushing");
										spec.getJvmArgs().add("-XX:+UseFastJNIAccessors");
										spec.getJvmArgs().add("-XX:+CMSScavengeBeforeRemark");
										spec.getJvmArgs().add("-XX:+ExplicitGCInvokesConcurrentAndUnloadsClasses");
										spec.getJvmArgs().add("-XX:+ScavengeBeforeFullGC");
										spec.getJvmArgs().add("-XX:+AlwaysPreTouch");
										spec.getJvmArgs().add("-XX:+UseFastAccessorMethods");
										spec.getJvmArgs().add("-XX:+UnlockExperimentalVMOptions");
										spec.getJvmArgs().add("-XX:G1HeapWastePercent=10");
										spec.getJvmArgs().add("-XX:G1MaxNewSizePercent=10");
										spec.getJvmArgs().add("-XX:G1HeapRegionSize=32M");
										spec.getJvmArgs().add("-XX:G1NewSizePercent=10");
										spec.getJvmArgs().add("-XX:MaxGCPauseMillis=100");
										spec.getJvmArgs().add("-XX:+OptimizeStringConcat");
										spec.getJvmArgs().add("-XX:+UseParNewGC");
										spec.getJvmArgs().add("-XX:+UseNUMA");
										spec.getJvmArgs().add("-XX:+AlwaysTenure");
										spec.getJvmArgs().add("-XX:+UseCompressedOops");
										spec.getJvmArgs().add("-XX:G1NewSizePercent=10");
										spec.getJvmArgs().add("-XX:G1ReservePercent=10");
										spec.getJvmArgs().add("-XX:+UseConcMarkSweepGC");
										spec.getJvmArgs().add("-XX:+CMSClassUnloadingEnabled");
										spec.getJvmArgs().add("-XX:SurvivorRatio=2");
										spec.getJvmArgs().add("-XX:+DisableExplicitGC");
										spec.getJvmArgs().add("-Dfml.readTimeout=120");
										if (settings.getPack().equals("skyblock")) {
											spec.getLaunchArgs().add("--server technicworld.pl --port 25565");
										} else if(settings.getPack().equals("survival")) {
											spec.getLaunchArgs().add("--server technicworld.pl --port 25566");
										}
										System.out.println(spec.getLaunchArgs());
										System.out.println(spec.getJvmArgs());

										//System.out.println(Paths.get(System.getProperty("java.home"), "bin", OS.getCURRENT() == OS.WINDOWS ? "java.exe" : "java"));
										if (task.getCompletedPercentage() == 100) {
								
											javafx.application.Platform.runLater( () -> consolePane.setVisible(true) );
											javafx.application.Platform.runLater( () -> downloadInfo.setText("Uruchomiono minecraft!"));
											javafx.application.Platform.runLater( () -> downloadProgress.setProgress(ProgressBar.INDETERMINATE_PROGRESS));
											javafx.application.Platform.runLater( () -> downloadIcon.setGlyphName("GAMEPAD"));
											hideDownloadPane();

									     BufferedReader reader = new BufferedReader(new InputStreamReader(spec.run(Paths.get(System.getProperty("java.home"), "bin", OS.getCURRENT() == OS.WINDOWS ? "java.exe" : "java")).getInputStream()));
									        if(!settings.getConsole()) {
												DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
												LocalDateTime now = LocalDateTime.now();
												File theDir = new File(System.getProperty("user.home")+"//TechnicWorld//MinecraftLogs");
												if (!theDir.exists()) {
													theDir.mkdir();
												}
									            String filePath = System.getProperty("user.home")+"//TechnicWorld//MinecraftLogs//minecraft-"+settings.getPack()+"_v"+settings.getPackVersion()+"_"+dtf.format(now)+".txt";

									           
									            try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath))) {
									                writer.write(console.getText());
									            } catch (IOException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													//erroralert(e);
												}
									            	try {
														Thread.sleep(4000);
													} catch (InterruptedException e) {
														// TODO Auto-generated catch block
														e.printStackTrace();
														//erroralert(e);
													}
									            	settings.saveSettings();
											      Platform.exit();
											      System.exit(0);
									        }
									            try {
													while ((line = reader.readLine()) != null) {
													    //System.out.println(line);
														javafx.application.Platform.runLater( () -> console.appendText(line+"\r\n") );
													}
													
												} catch (IOException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													//erroralert(e);
												}
									            try {
													reader.close();
												} catch (IOException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													//erroralert(e);
												}
									            File theDir = new File(System.getProperty("user.home")+"//TechnicWorld//MinecraftLogs");
									            
										   	     // if the directory does not exist, create it
										   	     if (!theDir.exists()) {
										   	         boolean result = false;
										   	
										   	         try{
										   	             theDir.mkdirs();
										   	             result = true;
										   	         } 
										   	         catch(SecurityException se){
										   	        	//erroralert(se);
										   	             //handle it
										   	         }        
										   	         if(result) {    
										   	             System.out.println("DIR created");  
										   	         }
										   	     }
									            consolePane.setVisible(false);
									            console.appendText("\r\n**** END ****");
												DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");
												LocalDateTime now = LocalDateTime.now();
									            String filePath = System.getProperty("user.home")+"//TechnicWorld//MinecraftLogs//minecraft-"+settings.getPack()+"_v"+settings.getPackVersion()+"_"+dtf.format(now)+".txt";

									           
									            try (BufferedWriter writer = Files.newBufferedWriter(Paths.get(filePath))) {
									                writer.write(console.getText());
									            } catch (IOException e) {
													// TODO Auto-generated catch block
													e.printStackTrace();
													//erroralert(e);
												}
									            settings.saveSettings();
									            System.out.println("MC stopped");
									            //lock(false);
												//atDownloadMods = false;
												//atLogin = false;
												//atRunMinecraft = false;
												javafx.application.Platform.runLater( () -> consolePane.setVisible(false) );
									      		//javafx.application.Platform.runLater( () -> progresspane.setVisible(false) );
									      		//javafx.application.Platform.runLater( () -> progress.setProgress(ProgressBar.INDETERMINATE_PROGRESS) );
												//javafx.application.Platform.runLater( () -> download.setText("") );
										}
			            }};
				    new Thread(updatethread).

				    start();
					
				} catch(Exception e) {
					e.printStackTrace();
					//erroralert(e);
				}
			}	
		}
}
