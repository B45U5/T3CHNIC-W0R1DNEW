package pl.B4GU5.TW;

import java.io.FileNotFoundException;
import java.io.IOException;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import pl.B4GU5.Utils.settings;

public class Main extends Application {
	static Stage stage;
	@Override
	public void start(Stage primaryStage) throws IOException {
		stage = primaryStage;
		Parent root = FXMLLoader.load(getClass().getResource("Main.fxml"));
		
		Scene scene = new Scene(root, 853, 504);
		stage.setScene(scene);
		stage.setMinHeight(540);
		stage.setMinWidth(960);
		stage.centerOnScreen();
		stage.setTitle("TechnicWorld | Serwery na modach!");
        stage.setOnCloseRequest(new EventHandler<WindowEvent>() {
			public void handle(WindowEvent t) {
				settings.saveSettings();
				Platform.exit();
			    System.exit(0);
			}
		});

		stage.show();
	}

	public static void main(String[] args) throws FileNotFoundException {
		launch(args);
	}
	public static void changeStageName(String str) {
		stage.setTitle(str);
	}
}
