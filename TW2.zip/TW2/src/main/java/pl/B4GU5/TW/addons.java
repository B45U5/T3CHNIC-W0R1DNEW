package pl.B4GU5.TW;


import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Text;

public class addons {

	//Kontroler itemu listy
	String ID0 = "";
    @FXML
	private Text nazwa;
    @FXML
	private Text autor;
    @FXML
	private Text opis;
    @FXML
	private Text diaxy;
    @FXML
	private Text wersja;
    @FXML
	private Pane obrazek;
    @FXML
	private Pane tlo;
    @FXML
	private Text typ;
    @FXML
	private Text pobran;
    @FXML
	private Button playBTN;
    @FXML
	private Text kiedy;
    public boolean active = false;
	@FXML
	   private void initialize() {
	       nazwa.setText("Wczytuję...");
	   }
	   public void aktywuj() {
		   active = true;
	   }
	   public void deaktywuj() {
		   active = false;
	   }
	   public boolean aktywny_infor() {
		   return active;
	   }
	   public void Nazwa(String tekst) {
		   nazwa.setText(tekst);
	   }
	   public void aktywny() {
		   Border bor = new Border(new BorderStroke(Color.SPRINGGREEN, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT));
		   obrazek.setBorder(bor);
		   tlo.setStyle("-fx-background-color: linear-gradient(to right, rgba(16, 224, 112, 0.7), rgba(57, 113, 123, 0.0));;");
	   }
	   public void nieaktywny() {
		   Border bor = new Border(new BorderStroke(Color.ORANGERED, BorderStrokeStyle.SOLID, CornerRadii.EMPTY, BorderWidths.DEFAULT));
		   obrazek.setBorder(bor);
		   tlo.setStyle("-fx-background-color: linear-gradient(to right, rgba(226, 17, 17, 0.7), rgba(57, 113, 123, 0.0));");
	   }
	   public void Obrazek(String tekst) {
		   obrazek.setStyle("-fx-background-image: url('"+tekst+"'); -fx-shape:  \"M0 13 C0 5 5 0 13 0 L86 0 C94 0 99 5 99 13 L99 86 C99 94 94 99 86 99 L13 99 C5 99 0 94 0 86Z\"; -fx-background-size: cover;");
	   }
	   public void ID(String tekst) {
		   ID0 = tekst;
	   }
}
