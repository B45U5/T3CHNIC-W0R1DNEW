package pl.B4GU5.Utils;

public class LogType {
	public static String info() {
		return "info";
	}
	
	public static String warn() {
		return "warn";
	}
	
	public static String error() {
		return "error";
	}
}