package pl.B4GU5.Utils;

public interface LogType {
	public static String info() {
		return "info";
	}
	
	public static String warn() {
		return "warn";
	}
	
	public static String error() {
		return "error";
	}
}